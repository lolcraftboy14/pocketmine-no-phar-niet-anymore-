# pocketmine-no-phar-niet-anymore-
er no phar neet it anymore its steel in beta
 help need it realy hard plz
