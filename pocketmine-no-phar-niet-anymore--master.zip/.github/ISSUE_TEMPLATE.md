### Issue description
<!--- use our forum https://forums.pocketmine.net for questions -->
Write a short description about the issue

### Steps to reproduce the issue
<!--- help us find the problem by adding steps to reproduce the issue -->
1. ...
2. ...

### OS and versions
<!--- use the 'version' command in PocketMine-MP -->
* PocketMine-MP:
* PHP:
* OS:

### Crashdump, backtrace or other files
<!--- please use gist or anything else and add links here -->
* ...
